# PV Ray-Optics Engine — Parameter Manual

**Script:** `pv_ray_optics.py`  
**Purpose:** Design a concentrator lens that focuses sunlight (400–1100 nm) onto a silicon PV cell.  
**Audience:** Engineers modifying lens geometry, materials, or simulation settings.

---

## Quick-Start Checklist

1. Install Python 3.10+
2. Run `python -m pip install numpy scipy matplotlib`
3. Edit the parameters described in this manual (all in `main()` or the labelled functions)
4. Run `python pv_ray_optics.py`
5. Check the 4 saved PNG files and the console table

---

## Parameter Reference

### 1. Lens Geometry — `x0`

**Location:** `main()` function, near the top  
**Line to find:** `x0 = np.array([...])`

```python
x0 = np.array([50e-3, -30e-3, -50e-3, 5e-3, 5e-3, 50e-3])
#               R0      R1      R2      t1    t2    f
```

All values are in **metres** (`50e-3` = 50 mm).

| Parameter | Position in array | Meaning | Typical range |
|---|---|---|---|
| `R0` | `x0[0]` | Radius of curvature of the **entry** surface (air → glass 1) | +20 mm to +200 mm |
| `R1` | `x0[1]` | Radius of curvature of the **middle** surface (glass 1 → glass 2) | −200 mm to +200 mm |
| `R2` | `x0[2]` | Radius of curvature of the **exit** surface (glass 2 → air) | −200 mm to −20 mm |
| `t1` | `x0[3]` | Thickness of **layer 1** (glass 1) | 2 mm to 20 mm |
| `t2` | `x0[4]` | Thickness of **layer 2** (glass 2) | 2 mm to 20 mm |
| `f`  | `x0[5]` | Target **focal length** (distance from lens to PV cell) | 20 mm to 200 mm |

**Sign convention for radii:**

| Sign of R | Meaning | Effect on a forward-travelling ray |
|---|---|---|
| Positive (`+`) | Centre of curvature is to the **right** (+z) | Converging (focuses light) |
| Negative (`−`) | Centre of curvature is to the **left** (−z) | Diverging (spreads light) |

**Common starting configurations:**

```python
# Short focal length (~25 mm) — compact concentrator
x0 = np.array([25e-3, -15e-3, -25e-3, 4e-3, 4e-3, 25e-3])

# Long focal length (~100 mm) — more working distance
x0 = np.array([100e-3, -60e-3, -100e-3, 8e-3, 8e-3, 100e-3])

# Symmetric biconvex (good neutral starting point)
x0 = np.array([50e-3, -50e-3, -50e-3, 5e-3, 5e-3, 50e-3])
```

---

### 2. Glass Materials — `mat1` and `mat2`

**Location:** `optimize_lens()` call inside `main()`, or passed directly.

```python
opt = optimize_lens(mat1=Material.BK7(), mat2=Material.F2(), x0=x0)
```

**Built-in materials:**

| Name | Code | nD (at 587 nm) | Abbe V | Character |
|---|---|---|---|---|
| N-BK7 | `Material.BK7()` | 1.517 | 64.2 | Crown — low dispersion, cheap |
| N-FK51A | `Material.FK51A()` | 1.487 | 84.5 | Extra-low dispersion crown |
| F2 | `Material.F2()` | 1.620 | 36.4 | Flint — high dispersion |
| SF11 | `Material.SF11()` | 1.785 | 25.8 | Dense flint — very high dispersion |
| N-LASF9 | `Material.LASF9()` | 1.850 | 32.2 | Lanthanum flint — high index |

**Pairing guide:**
- Combine a **crown** (high Abbe V) with a **flint** (low Abbe V) to correct chromatic aberration
- Larger difference in Abbe numbers = better chromatic correction
- Recommended pairs for broadband (400–1100 nm): `BK7+SF11`, `FK51A+SF11`, `FK51A+LASF9`

**To add a custom material** (get B and C from the Schott glass catalogue):

```python
# Add this near the top of the file, after the Material class
MY_GLASS = Material("MyGlass",
    B=[1.03961212, 0.231792344, 1.01046945],   # Sellmeier B coefficients
    C=[6.00069867e-15, 2.00179144e-14, 1.03560653e-10])  # C coefficients [m²]

# Then use it:
opt = optimize_lens(mat1=MY_GLASS, mat2=Material.SF11(), x0=x0)
```

> **Note:** Sellmeier C coefficients in the Schott catalogue are in **µm²**.  
> Convert to m²: multiply by `1e-12`.  
> Example: `0.006` µm² → `6e-15` m²

---

### 3. Input Ray Bundle — `make_input_bundle()`

**Location:** `make_input_bundle()` function, and calls to it in `main()`.

```python
rays_in = make_input_bundle(radius=1e-3, n_rays=25)
```

| Parameter | Meaning | Effect of increasing |
|---|---|---|
| `radius` | Half-width of the input aperture [m] | Larger aperture → tests more off-axis aberration |
| `n_rays` | Approximate number of rays (rounded to nearest perfect square) | More rays → smoother spot diagram, slower run |

**Recommended values:**

| Use case | radius | n_rays |
|---|---|---|
| Fast scan / survey | `1e-3` (1 mm) | `9` |
| Standard design | `1e-3` (1 mm) | `25` |
| High accuracy | `2e-3` (2 mm) | `49` |
| Large aperture lens | `5e-3` (5 mm) | `49` |

---

### 4. Wavelength Grid — `LAMBDA_GRID`

**Location:** Near the top of the file, after the `pv_weight()` function.

```python
LAMBDA_GRID = np.linspace(400e-9, 1100e-9, 15)
```

| Parameter | Meaning | Trade-off |
|---|---|---|
| Start wavelength | `400e-9` = 400 nm | Lower limit of UV coverage |
| End wavelength | `1100e-9` = 1100 nm | Upper limit (Si bandgap edge) |
| Number of points | `15` | More points = slower but more accurate cost |

**To focus only on the peak Si PV band:**
```python
LAMBDA_GRID = np.linspace(500e-9, 900e-9, 10)
```

---

### 5. Spectral Weight Function — `pv_weight()`

**Location:** `pv_weight()` function.

```python
def pv_weight(lam: float) -> float:
    return 2.0 if 500e-9 <= lam <= 900e-9 else 1.0
```

This makes the optimizer try twice as hard to minimise spot size in the 500–900 nm band (peak silicon PV quantum efficiency).

**To match a different cell technology:**

| Cell type | Peak band | Change to |
|---|---|---|
| Silicon (default) | 500–900 nm | *(no change)* |
| GaAs | 600–900 nm | `600e-9 <= lam <= 900e-9` |
| Perovskite | 400–800 nm | `400e-9 <= lam <= 800e-9` |
| Full spectrum equal weight | — | `return 1.0` |

**To apply a custom AM1.5 solar spectrum weight**, replace the function with:

```python
def pv_weight(lam: float) -> float:
    # Rough AM1.5G peak weighting by wavelength band
    if   lam < 400e-9:  return 0.1
    elif lam < 500e-9:  return 1.0
    elif lam < 700e-9:  return 2.5   # peak solar irradiance
    elif lam < 900e-9:  return 2.0
    elif lam < 1100e-9: return 1.0
    else:               return 0.1
```

---

### 6. Optimizer Settings — `optimize_lens()`

**Location:** `optimize_lens()` function definition.

```python
opt = optimize_lens(
    mat1    = Material.BK7(),
    mat2    = Material.F2(),
    x0      = x0,
    method  = "Nelder-Mead",
    maxiter = 1500
)
```

| Parameter | Meaning | When to change |
|---|---|---|
| `method` | Optimization algorithm | See table below |
| `maxiter` | Maximum number of iterations | Increase if "converged=False" in output |

**Method options:**

| Method | Speed | When to use |
|---|---|---|
| `"Nelder-Mead"` | Medium | Default — works without gradients, robust |
| `"Powell"` | Fast | Good alternative if Nelder-Mead stalls |
| `"L-BFGS-B"` | Fastest | Use if cost is smooth (may miss global minimum) |

**Fast coarse grid during search** (also inside `optimize_lens()`):

```python
FAST_LAMS = np.linspace(400e-9, 1100e-9, 7)   # wavelengths used during search
```

Reduce to `5` for faster iterations; increase to `11` for more accuracy during search.

---

### 7. Material Survey — `material_survey()`

**Location:** `material_survey()` function and `CANDIDATE_MATERIALS` dict.

```python
CANDIDATE_MATERIALS = {
    "N-BK7":   Material.BK7(),
    "F2":      Material.F2(),
    "SF11":    Material.SF11(),
    "N-LASF9": Material.LASF9(),
    "N-FK51A": Material.FK51A(),
}
```

The survey scores every ordered pair of materials at the starting geometry `x0` and prints a ranked table. The best pair is then passed to the optimizer.

**To add a material to the survey:**
```python
CANDIDATE_MATERIALS["MyGlass"] = MY_GLASS   # add after defining MY_GLASS
```

**To skip the survey** and go straight to optimization with a fixed pair, in `main()` replace:
```python
scores = material_survey(x0)
best_m1 = CANDIDATE_MATERIALS[scores[0][1]]
best_m2 = CANDIDATE_MATERIALS[scores[0][2]]
opt = optimize_lens(mat1=best_m1, mat2=best_m2, x0=x0)
```
with:
```python
opt = optimize_lens(mat1=Material.BK7(), mat2=Material.SF11(), x0=x0)
```

---

## Reading the Output

### Console table

```
── Per-wavelength RMS at PV plane ───────────────────────
     λ [nm]  weight    RMS [µm]
      400.0     1.0      12.345
      550.0     2.0       1.234   ← weighted 2×, most important
      900.0     2.0       2.345
     1100.0     1.0       8.901
```

- **RMS [µm]** = root-mean-square spot radius on the PV plane. Lower = tighter focus = better concentration.
- **Target:** < 50 µm across 500–900 nm for a good concentrator; < 10 µm for high-concentration designs.

### Output files

| File | What it shows | What to look for |
|---|---|---|
| `focus_shift_initial.png` | Focus shift vs wavelength (before optimization) | Flat line = low chromatic aberration |
| `spots_initial.png` | Spot pattern at each wavelength (before) | Tight clusters near centre |
| `spots_optimised.png` | Spot pattern at each wavelength (after) | Should be much tighter than initial |
| `rms_comparison.png` | RMS before (red) vs after (blue) across spectrum | Blue line should be well below red |

---

## Common Modifications

### Change the focal length target
```python
# In main(), change the last element of x0:
x0 = np.array([50e-3, -30e-3, -50e-3, 5e-3, 5e-3, 75e-3])
#                                                   ↑ 75 mm focal length
```

### Use thicker lens elements
```python
x0 = np.array([50e-3, -30e-3, -50e-3, 10e-3, 10e-3, 50e-3])
#                                       ↑ t1    ↑ t2  (10 mm each)
```

### Run faster (coarser simulation)
In `main()`:
```python
# Reduce rays in the focus-shift plot
# find make_input_bundle() calls and change n_rays=9
rays_in = make_input_bundle(radius=1e-3, n_rays=9)
```

### Run more accurately (finer simulation)
```python
LAMBDA_GRID = np.linspace(400e-9, 1100e-9, 25)   # 25 wavelengths
rays_in = make_input_bundle(radius=1e-3, n_rays=49)  # 49 rays
```

---

## Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| `converged=False` | Optimizer hit `maxiter` | Increase `maxiter` to `3000` |
| Final cost > initial cost | Optimizer diverged | Try `method="Powell"` or change `x0` |
| Many `(no rays)` panels in spot diagram | Rays missing the surfaces | Radii too small — increase `R0`, `R1`, `R2` |
| All spots at same large radius | Lens not focusing at `f` | Adjust `f` to match actual focus; run `plot_focus_shift()` first |
| Script hangs at material survey | 20 evaluations × many rays | Temporarily set `n_rays=9` in `make_input_bundle()` |
| `nan` in RMS table | TIR or ray loss at a surface | Reduce incidence angle: use larger `R0` or smaller aperture `radius` |
